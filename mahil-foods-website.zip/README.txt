# Mahil Foods Website

A free, mobile-friendly one-page website for Mahil Foods.

## Publish free with GitHub Pages

1. Create/sign in to a GitHub account.
2. Create a new **public** repository named `mahil-foods`.
3. Upload `index.html`.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, select **Deploy from a branch**.
6. Select `main` and `/ (root)`, then save.
7. GitHub will provide a free website address similar to:
   `https://YOUR-USERNAME.github.io/mahil-foods/`

The phone and WhatsApp buttons are already configured for 7702094095.
